import UserAPI from './user'
import MarketAPI from './student/market'
import ReceiverAPI from './receiver'
import feedback from './student/feedback'
import recycle from './student/recycle'
export { UserAPI, MarketAPI, ReceiverAPI, feedback, recycle }
