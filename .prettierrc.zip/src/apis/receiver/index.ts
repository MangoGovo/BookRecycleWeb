import currentOrder from './currentOrder'
import { orders, takeOrder, submitOrder, settleOrder } from './orders'
export default { currentOrder, orders, takeOrder, submitOrder, settleOrder }
