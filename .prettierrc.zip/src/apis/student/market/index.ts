import { products, uploadProducts, getMyProducts, delMyProduct, editMyProducts } from './products'
import orders from './orders'
export default { products, orders, uploadProducts, getMyProducts, delMyProduct, editMyProducts }
