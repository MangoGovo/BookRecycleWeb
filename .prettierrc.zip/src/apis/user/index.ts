import login from './login'
import register from './register'
import activate from './activate'
import info from './info'
export default { login, register, activate, info }
