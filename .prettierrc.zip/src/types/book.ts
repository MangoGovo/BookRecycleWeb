export type book = {
  id: number
  user_id: number
  name: string
  author:string
  course: string
  edition: string
  publisher: string
  completeness: string // 完好程度
  img: string
  price: string
  note: string
}
