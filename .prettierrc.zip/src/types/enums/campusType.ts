enum CampusType {
  ZH = 1,
  PF = 2,
  MGS = 3
}
export default CampusType
