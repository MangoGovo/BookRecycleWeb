enum UserType {
  Student = 1,
  Receiver = 2,
  Admin = 3
}
export default UserType
