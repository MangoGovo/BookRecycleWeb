export type oldBook = {
  id: number
  seller: number
  seller_name: string
  weight: number
  address: string
  note: string
  img: string
  upload_time: string
}
