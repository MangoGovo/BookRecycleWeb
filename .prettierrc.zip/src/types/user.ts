type UserInfo = {
    username:string;
}