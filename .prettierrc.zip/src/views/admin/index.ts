import HomeView from './home/index.vue'
export default { HomeView }
