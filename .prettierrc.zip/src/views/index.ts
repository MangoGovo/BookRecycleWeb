import UserViews from './user'
import AdminViews from './admin'
import StudentViews from './student'
import ReceiverViews from './receiver'
export { UserViews, AdminViews, StudentViews, ReceiverViews }
