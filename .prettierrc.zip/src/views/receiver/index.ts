import HomeView from './home/index.vue'
import CheckView from './check/index.vue'
export default { HomeView, CheckView }
