import HomeView from './home/index.vue'
import SellView from './sell/index.vue'
import MarketView from './market/index.vue'
import ChatView from './chat/index.vue'
export default { HomeView, SellView, MarketView, ChatView }
