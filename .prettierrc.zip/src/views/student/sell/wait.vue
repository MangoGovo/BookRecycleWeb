<template>
    <div class="flex flex-row flex-grow justify-center my-180 items-center gap-100">
      <div>
        <el-icon size="280">
        <Document />
      </el-icon>
      </div>
      <div class="flex flex-col">
        <div class="my-20 text-4xl mt-20">等待收书员接单...</div>
      </div>
    </div>
  </template>