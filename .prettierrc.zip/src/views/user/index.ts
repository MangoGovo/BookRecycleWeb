import LoginView from './login/index.vue'
import RegisterView from './register/index.vue'
import ForgetView from './forget/index.vue'
import UserCenterView from './usercenter/index.vue'
export default { LoginView, RegisterView, ForgetView, UserCenterView }
    